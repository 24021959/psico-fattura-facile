import { UserSupportTickets } from '@/components/support/UserSupportTickets';

export default function Support() {
  return (
    <div className="container mx-auto p-6">
      <UserSupportTickets />
    </div>
  );
}