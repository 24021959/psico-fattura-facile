-- Aggiungere colonna metodo_pagamento alla tabella fatture
ALTER TABLE public.fatture ADD COLUMN metodo_pagamento TEXT;